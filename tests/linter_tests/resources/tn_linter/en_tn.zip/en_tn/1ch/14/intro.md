# 1 Chronicles 14 General Notes #

#### Special concepts in this chapter ####

David asked for help from God and because of this, God enabled him to defeat the Philistines when they tried to capture him. 

## Links: ##

* __[1 Chronicles 14:01 Notes](./01.md)__

__[<<](../13/intro.md) | [>>](../15/intro.md)__
