# 1 Chronicles 06 General Notes #

#### Structure and formatting ####

This chapter records the descendants of Levi.

## Links: ##

* __[1 Chronicles 06:01 Notes](./01.md)__

__[<<](../05/intro.md) | [>>](../07/intro.md)__
