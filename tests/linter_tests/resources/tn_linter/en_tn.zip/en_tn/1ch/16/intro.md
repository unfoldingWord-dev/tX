# 1 Chronicles 16 General Notes #

#### Structure and formatting ####

Chapters 15 and 16 tell how David organized the priests and Levites. (See: [[rc://en/tw/dict/bible/kt/priest]])

Some translations indent each line of poetry to make it easier to read. The ULB does this with the poetic song in 16:8-36.

#### Special concepts in this chapter ####

##### David's psalm #####
As David organized the priests in their work in the tent, he wrote a psalm of praise to Yahweh.

## Links: ##

* __[1 Chronicles 16:01 Notes](./01.md)__

__[<<](../15/intro.md) | [>>](../17/intro.md)__
