# 1 Chronicles 12 General Notes #

#### Special concepts in this chapter ####

##### "[They] could use both the right hand and the left" #####
These soldiers were very skilled. They were able to fight with either hand. (See: [[rc://en/ta/man/translate/figs-explicit]])

##### King David #####
This chapter records all those who supported David as king over Saul. The extent of this record shows that there was nearly universal support for David. 

## Links: ##

* __[1 Chronicles 12:01 Notes](./01.md)__

__[<<](../11/intro.md) | [>>](../13/intro.md)__
