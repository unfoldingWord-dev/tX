# 1 Chronicles 24 General Notes #

#### Structure and formatting ####

The preparation for the temple continues in this chapter. (See: [[rc://en/tw/dict/bible/kt/temple]])

#### Special concepts in this chapter ####

##### Arranging the priests #####
David arranged for the order in which priests would be on duty. (See: [[rc://en/tw/dict/bible/kt/priest]])

## Links: ##

* __[1 Chronicles 24:01 Notes](./01.md)__

__[<<](../23/intro.md) | [>>](../25/intro.md)__
