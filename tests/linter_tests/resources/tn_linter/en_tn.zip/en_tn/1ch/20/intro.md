# 1 Chronicles 20 General Notes #

#### Structure and formatting ####

This chapter ends the story of the war with Ammon and tells of giants being killed by David's soldiers.

#### Special concepts in this chapter ####

##### "When kings normally go to war" #####
It was advantageous for kings to go to war in the springtime. This was possibly due to the weather being neither too hot nor too cold. 

#### Other possible translation difficulties in this chapter ####

##### "It came about" #####
This is a phrase used to indicate the next event in a series. It can often be translated as "after," "then" or "next."
## Links: ##

* __[1 Chronicles 20:01 Notes](./01.md)__

__[<<](../19/intro.md) | [>>](../21/intro.md)__
