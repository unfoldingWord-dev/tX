# 1 Chronicles 25 General Notes #

#### Structure and formatting ####

The preparation for the temple continues in this chapter. (See: [[rc://en/tw/dict/bible/kt/temple]])

#### Special concepts in this chapter ####

##### Music #####
The 24 groups who were chosen to play music in the temple cast lots to see in what order they would serve. 

## Links: ##

* __[1 Chronicles 25:01 Notes](./01.md)__

__[<<](../24/intro.md) | [>>](../26/intro.md)__
