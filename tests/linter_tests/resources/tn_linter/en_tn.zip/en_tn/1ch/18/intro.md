# 1 Chronicles 18 General Notes #

#### Special concepts in this chapter ####

##### David's victories #####
David conquered all kingdoms neighboring Israel. The gold, silver and bronze he received from these victories, he saved for building the temple. This may indicate that he believed that the victories were because of Yahweh and therefore the goods received in victory belonged to him. (See: [[rc://en/tw/dict/bible/kt/temple]])

## Links: ##

* __[1 Chronicles 18:01 Notes](./01.md)__

__[<<](../17/intro.md) | [>>](../19/intro.md)__
