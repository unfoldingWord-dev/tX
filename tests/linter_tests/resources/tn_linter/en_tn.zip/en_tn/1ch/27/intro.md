# 1 Chronicles 27 General Notes #

#### Structure and formatting ####

The preparation for the temple continues in this chapter. (See: [[rc://en/tw/dict/bible/kt/temple]])

## Links: ##

* __[1 Chronicles 27:01 Notes](./01.md)__

__[<<](../26/intro.md) | [>>](../28/intro.md)__
