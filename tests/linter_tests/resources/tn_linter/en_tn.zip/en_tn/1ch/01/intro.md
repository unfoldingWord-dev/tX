# 1 Chronicles 01 General Notes #

#### Structure and formatting ####

This chapter gives the genealogies of Abraham, Esau and the early kings of Edom.

## Links: ##

* __[1 Chronicles 01:01 Notes](./01.md)__
* __[1 Chronicles intro](../front/intro.md)__

__| [>>](../02/intro.md)__
