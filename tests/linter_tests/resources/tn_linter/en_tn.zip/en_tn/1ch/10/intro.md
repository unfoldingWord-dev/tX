# 1 Chronicles 10 General Notes #

#### Special concepts in this chapter ####

##### The death of Saul #####

Saul died because he disobeyed God. 

## Links: ##

* __[1 Chronicles 10:01 Notes](./01.md)__

__[<<](../09/intro.md) | [>>](../11/intro.md)__
