# 1 Chronicles 29 General Notes #

#### Structure and formatting ####

The preparation for the temple is finished in this chapter. (See: [[rc://en/tw/dict/bible/kt/temple]])

#### Special concepts in this chapter ####

##### Offering #####
David and the people made a free will offering and dedicated it all to God. 

## Links: ##

* __[1 Chronicles 29:01 Notes](./01.md)__

__[<<](../28/intro.md) | __
